This is a very simple skeleton file that will work with
hangoutiframer.appspot.com.  It will allow you to run
a Hangout App in its own iframe on your site.

See: http://hangoutiframer.appspot.com/ for help
with this file and instructions on how to use it.
